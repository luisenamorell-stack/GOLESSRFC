import { config } from 'dotenv';
config();

import '@/ai/flows/match-summary-generator.ts';