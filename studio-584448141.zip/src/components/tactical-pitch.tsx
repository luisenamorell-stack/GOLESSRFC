
"use client";

import React from 'react';
import { Player, Team, MatchEvent } from '@/types/match';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Target, ArrowRightLeft, User } from "lucide-react";

interface TacticalPitchProps {
  homeTeam: Team;
  awayTeam: Team;
  events: MatchEvent[];
}

export function TacticalPitch({ homeTeam, awayTeam, events }: TacticalPitchProps) {
  const renderPlayers = (team: Team, side: 'home' | 'away') => {
    const players = team.players || [];
    
    // Group players by position
    const gks = players.filter(p => p.position === 'GK');
    const defs = players.filter(p => p.position === 'DEF');
    const mids = players.filter(p => p.position === 'MID');
    const fwds = players.filter(p => p.position === 'FWD');

    const getPlayerStats = (playerName: string) => {
      const playerEvents = events.filter(e => e.playerName === playerName);
      return {
        goals: playerEvents.filter(e => e.type === 'goal' || e.type === 'penalty').length,
        yellow: playerEvents.filter(e => e.type === 'yellow_card').length,
        red: playerEvents.filter(e => e.type === 'red_card').length,
        sub: playerEvents.filter(e => e.type === 'substitution').length
      };
    };

    const renderRow = (playerList: Player[], rowY: string) => (
      <div className="absolute w-full flex justify-around" style={{ top: rowY }}>
        {playerList.map((player) => {
          const stats = getPlayerStats(player.name);
          return (
            <div key={player.id} className="flex flex-col items-center gap-1 group">
              <div className="relative">
                <Avatar className={`h-10 w-10 sm:h-12 sm:w-12 border-2 ${side === 'home' ? 'border-primary' : 'border-accent'} shadow-lg bg-background`}>
                  <AvatarImage src={player.photoUrl} className="object-cover" />
                  <AvatarFallback className="text-[10px] font-bold">{player.name[0]}</AvatarFallback>
                </Avatar>
                
                {/* Event indicators over avatar */}
                <div className="absolute -top-1 -right-1 flex flex-col gap-0.5">
                  {stats.goals > 0 && (
                    <div className="bg-yellow-500 rounded-full p-0.5 shadow-sm">
                      <Trophy className="h-2 w-2 text-white" />
                    </div>
                  )}
                  {stats.yellow > 0 && <div className="w-1.5 h-2 bg-yellow-400 rounded-sm shadow-sm" />}
                  {stats.red > 0 && <div className="w-1.5 h-2 bg-red-600 rounded-sm shadow-sm" />}
                </div>
              </div>
              
              <div className="bg-black/60 backdrop-blur-sm px-1.5 py-0.5 rounded text-[8px] sm:text-[10px] font-black text-white uppercase tracking-tighter truncate max-w-[60px] sm:max-w-[80px]">
                {player.name}
              </div>
              {player.number && (
                <Badge variant="secondary" className="h-3 px-1 text-[8px] opacity-70">#{player.number}</Badge>
              )}
            </div>
          );
        })}
      </div>
    );

    return (
      <div className={`absolute w-full h-1/2 left-0 ${side === 'away' ? 'top-0 rotate-180' : 'bottom-0'}`}>
        {/* If rotated, children will be upside down, so we re-rotate them inside renderRow if needed or handle with CSS */}
        <div className={side === 'away' ? 'rotate-180 w-full h-full relative' : 'relative w-full h-full'}>
          {side === 'home' ? (
            <>
              {renderRow(gks, '85%')}
              {renderRow(defs, '65%')}
              {renderRow(mids, '40%')}
              {renderRow(fwds, '15%')}
            </>
          ) : (
            <>
              {renderRow(gks, '5%')}
              {renderRow(defs, '25%')}
              {renderRow(mids, '50%')}
              {renderRow(fwds, '75%')}
            </>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-2xl mx-auto aspect-[2/3] relative rounded-[2rem] overflow-hidden border-4 border-white/10 shadow-2xl bg-[#1a3a2a]">
      {/* Pitch Grass Texture */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#1a4d2e] to-[#143d24]" />
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 10%, rgba(255,255,255,0.05) 10%, rgba(255,255,255,0.05) 20%)' }} />
      
      {/* Pitch Lines */}
      <div className="absolute inset-4 border-2 border-white/40" /> {/* Outer Line */}
      <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white/40" /> {/* Center Line */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border-2 border-white/40 rounded-full" /> {/* Center Circle */}
      
      {/* Home Area */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-48 h-24 border-2 border-white/40" /> {/* Large Box */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-24 h-10 border-2 border-white/40" /> {/* Small Box */}
      
      {/* Away Area */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-48 h-24 border-2 border-white/40" /> {/* Large Box */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-24 h-10 border-2 border-white/40" /> {/* Small Box */}

      {/* Players */}
      {renderPlayers(homeTeam, 'home')}
      {renderPlayers(awayTeam, 'away')}
    </div>
  );
}
